import { SwalOptions } from './options';
declare const addEventListeners: (opts: SwalOptions) => void;
export default addEventListeners;
